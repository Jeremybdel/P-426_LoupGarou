var searchData=
[
  ['name_130',['Name',['../class_classe___card_1_1_card.html#a24db21a16d77922173b50a324b772c60',1,'Classe_Card::Card']]]
];
