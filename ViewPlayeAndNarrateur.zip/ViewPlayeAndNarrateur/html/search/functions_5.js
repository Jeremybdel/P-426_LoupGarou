var searchData=
[
  ['hunter_112',['Hunter',['../class_classe___card_1_1_cards_1_1_hunter.html#a264acda1ec6500e0ea70de3e0dc89ac1',1,'Classe_Card::Cards::Hunter']]]
];
