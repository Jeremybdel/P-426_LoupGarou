var searchData=
[
  ['villager_117',['Villager',['../class_classe___card_1_1_cards_1_1_villager.html#aaae1ef2caacf8e7511679e3046fdbf8f',1,'Classe_Card::Cards::Villager']]]
];
