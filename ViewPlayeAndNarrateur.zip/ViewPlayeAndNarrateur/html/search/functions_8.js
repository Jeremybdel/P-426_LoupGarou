var searchData=
[
  ['player_115',['Player',['../class_classe___card_1_1_player.html#a18b682f228d0ed062688cf192dbfd51c',1,'Classe_Card::Player']]]
];
