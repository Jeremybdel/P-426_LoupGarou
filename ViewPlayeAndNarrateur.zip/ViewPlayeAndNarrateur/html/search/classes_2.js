var searchData=
[
  ['hunter_69',['Hunter',['../class_classe___card_1_1_cards_1_1_hunter.html',1,'Classe_Card::Cards']]]
];
