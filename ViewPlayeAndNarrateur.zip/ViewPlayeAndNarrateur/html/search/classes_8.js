var searchData=
[
  ['villager_76',['Villager',['../class_classe___card_1_1_cards_1_1_villager.html',1,'Classe_Card::Cards']]]
];
