var searchData=
[
  ['cards_79',['Cards',['../namespace_classe___card_1_1_cards.html',1,'Classe_Card']]],
  ['classe_5fcard_80',['Classe_Card',['../namespace_classe___card.html',1,'']]]
];
