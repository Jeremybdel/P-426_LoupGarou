var searchData=
[
  ['properties_81',['Properties',['../namespace_view_player_game_1_1_properties.html',1,'ViewPlayerGame']]],
  ['viewplayergame_82',['ViewPlayerGame',['../namespace_view_player_game.html',1,'']]]
];
