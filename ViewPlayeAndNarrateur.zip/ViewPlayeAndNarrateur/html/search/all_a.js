var searchData=
[
  ['player_32',['Player',['../class_classe___card_1_1_player.html',1,'Classe_Card.Player'],['../class_classe___card_1_1_player.html#a18b682f228d0ed062688cf192dbfd51c',1,'Classe_Card.Player.Player()']]],
  ['player_2ecs_33',['Player.cs',['../_player_8cs.html',1,'']]],
  ['priority_34',['Priority',['../class_classe___card_1_1_card.html#aafb452edaf3735c9ce206cd89ee717b8',1,'Classe_Card::Card']]],
  ['program_2ecs_35',['Program.cs',['../_program_8cs.html',1,'']]]
];
