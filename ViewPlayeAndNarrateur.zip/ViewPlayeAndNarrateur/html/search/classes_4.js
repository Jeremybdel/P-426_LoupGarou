var searchData=
[
  ['narrateur_71',['Narrateur',['../class_view_player_game_1_1_narrateur.html',1,'ViewPlayerGame']]]
];
