var searchData=
[
  ['priority_131',['Priority',['../class_classe___card_1_1_card.html#aafb452edaf3735c9ce206cd89ee717b8',1,'Classe_Card::Card']]]
];
