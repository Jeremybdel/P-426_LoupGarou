var searchData=
[
  ['player_72',['Player',['../class_classe___card_1_1_player.html',1,'Classe_Card']]]
];
