var searchData=
[
  ['voyantecall_136',['VoyanteCall',['../class_view_player_game_1_1_narrateur.html#a69d28478f6df158672489d9498fcb510',1,'ViewPlayerGame::Narrateur']]],
  ['voyantechoice_137',['VoyanteChoice',['../class_view_player_game_1_1_narrateur.html#a2cc83528257be37d3248f7ae0bb48fb0',1,'ViewPlayerGame::Narrateur']]],
  ['voyantesleep_138',['VoyanteSleep',['../class_view_player_game_1_1_narrateur.html#ac5a69ad9dfd226f2c43ab4036c04c81f',1,'ViewPlayerGame::Narrateur']]]
];
