var searchData=
[
  ['resources_73',['Resources',['../class_view_player_game_1_1_properties_1_1_resources.html',1,'ViewPlayerGame::Properties']]]
];
