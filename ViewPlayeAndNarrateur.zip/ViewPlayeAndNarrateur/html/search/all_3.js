var searchData=
[
  ['form1_18',['Form1',['../class_view_player_game_1_1_form1.html',1,'ViewPlayerGame.Form1'],['../class_view_player_game_1_1_form1.html#ac7e2463fbb03176854a0ceb2d82ba12d',1,'ViewPlayerGame.Form1.Form1()']]],
  ['form1_2ecs_19',['Form1.cs',['../_form1_8cs.html',1,'']]],
  ['form1_2edesigner_2ecs_20',['Form1.Designer.cs',['../_form1_8_designer_8cs.html',1,'']]]
];
