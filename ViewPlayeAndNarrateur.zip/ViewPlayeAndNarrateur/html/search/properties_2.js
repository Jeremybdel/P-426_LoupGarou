var searchData=
[
  ['iscalled_129',['IsCalled',['../class_classe___card_1_1_card.html#aca08234f13999c9b0f38068ab7b2b53d',1,'Classe_Card::Card']]]
];
