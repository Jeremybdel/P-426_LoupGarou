var searchData=
[
  ['resources_36',['Resources',['../class_view_player_game_1_1_properties_1_1_resources.html',1,'ViewPlayerGame::Properties']]],
  ['resources_2edesigner_2ecs_37',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]]
];
