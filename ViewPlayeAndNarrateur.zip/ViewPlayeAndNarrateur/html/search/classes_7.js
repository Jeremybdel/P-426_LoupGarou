var searchData=
[
  ['seer_74',['Seer',['../class_classe___card_1_1_cards_1_1_seer.html',1,'Classe_Card::Cards']]],
  ['settings_75',['Settings',['../class_view_player_game_1_1_properties_1_1_settings.html',1,'ViewPlayerGame::Properties']]]
];
