var searchData=
[
  ['werewolf_77',['WereWolf',['../class_classe___card_1_1_cards_1_1_were_wolf.html',1,'Classe_Card::Cards']]],
  ['witch_78',['Witch',['../class_classe___card_1_1_cards_1_1_witch.html',1,'Classe_Card::Cards']]]
];
