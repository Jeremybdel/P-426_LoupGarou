var searchData=
[
  ['name_28',['Name',['../class_classe___card_1_1_card.html#a24db21a16d77922173b50a324b772c60',1,'Classe_Card::Card']]],
  ['narrateur_29',['Narrateur',['../class_view_player_game_1_1_narrateur.html',1,'ViewPlayerGame']]],
  ['narrateur_2ecs_30',['Narrateur.cs',['../_narrateur_8cs.html',1,'']]]
];
