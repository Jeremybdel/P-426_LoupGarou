var searchData=
[
  ['geteliminated_110',['GetEliminated',['../class_classe___card_1_1_player.html#af473b41578759efaebf25c3eb3ac423a',1,'Classe_Card::Player']]],
  ['givecard_111',['GiveCard',['../class_classe___card_1_1_player.html#a92da40571d071049264863af62750214',1,'Classe_Card::Player']]]
];
