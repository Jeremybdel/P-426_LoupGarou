﻿/*
 * ETML
 * 
 * Auteurs : Théo Brunner
 *           Daniel Gil
 *           
 * Date : 14.01.2020 - 25.02.2020
 * 
 * Description : Le but de ce programme est de reconstituer le jeu de carte du loup-garou. 
 *               Le jeu pourra être joué en multijoueur sur différents ordinateurs.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classe_Card
{
    public abstract class Card
    {
        public string Name { get; private set; }/**Nom de la carte*/
        public int Priority { get; private set; }/**Priorité par rapport au levé de la carte*/
        public bool IsCalled { get; private set; }/**Si la carte est appele chage en vrai et quand elle a fini son tour elle repase en false*/
        /// <summary>
        /// Constructeur de la classe
        /// </summary>
        /// <param name="name">Nom de la carte</param>
        /// <param name="priority">Priorité par rapport au levé de la carte</param>
        /// <param name="isCalled">Si la carte est appele chage en vrai et quand elle a fini son tour elle repase en false</param>
        public Card(string name, int priority, bool isCalled)
        {
            Name = name;
            Priority = priority;
            IsCalled = isCalled;
        }

        public abstract void WakeUp();

        public abstract void Die();
    }
}
