﻿/*
 * ETML
 * 
 * Auteurs : Théo Brunner
 *           Daniel Gil
 *           
 * Date : 14.01.2020 - 25.02.2020
 * 
 * Description : Le but de ce programme est de reconstituer le jeu de carte du loup-garou. 
 *               Le jeu pourra être joué en multijoueur sur différents ordinateurs.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classe_Card
{
    public class Player
    {
        private string _pseudo;/**Pseudo du joueur*/
        private bool isDead = false;

        private Card _card;
        public Card Card
        {
            get { return _card; }
            set { _card = value; }
        }


        public Player(string pseudo)
        {
            _pseudo = pseudo;
        }

        public void GiveCard(Card yourCard)
        {
            _card = yourCard;
        }

        public void GetEliminated()
        {
            isDead = true;
        }
    }
}
