﻿/*
 * ETML
 * 
 * Auteurs : Théo Brunner
 *           Daniel Gil
 *           
 * Date : 14.01.2020 - 25.02.2020
 * 
 * Description : Le but de ce programme est de reconstituer le jeu de carte du loup-garou. 
 *               Le jeu pourra être joué en multijoueur sur différents ordinateurs.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classe_Card.Cards
{
    public class Captain : Card
    {
        /// <summary>
        /// Constucteur de la classe 
        /// </summary>
        protected Captain() : base("Maire", 0 , false)
        {

        }

        public override void Die()
        {

        }

        public override void WakeUp()
        {

        }
    }
}
