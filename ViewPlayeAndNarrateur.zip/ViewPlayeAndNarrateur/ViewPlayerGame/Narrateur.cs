﻿///ETML
///Auteur : Brunner Théo
///Date : 11.02.2020
///Description : Interface du loup garou pour le plateau de jeux
///
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewPlayerGame
{
    public class Narrateur
    {
        public string SleepAll { get; private set; } = "Les Villageois s’endorment dans le magnifique village de thiercelieux";/**Phrase de couché des villageois*/
        public string CupidonCall { get; private set; } = "Cupidon se réveille et désigne les amoureux…";/**Phrase d'appele de cupidon*/
        public string CupidonChoice { get; private set; } = "Veuillez désigner les 2 amoureux…";/**Phrase de choix de cupidon*/
        public string CupidonSleep { get; private set; } = "Cupidon se rendort…";/**Phrase pour que cupidon se rendort*/
        public string Amoureux {get; private set; } = "Les Amoureux se réveillent, se reconnaissent, et se rendorment.";/**Phrase les amoureux se reveille*/
        public string VoyanteCall { get; private set; } = "Voyante se réveille…";/**Phrase pour que la voyante se reveille*/
        public string VoyanteChoice { get; private set; } = "Désignez un joueur à sonder… ";/**Phrase pour que la voyante choissit quelqu'un*/
        public string VoyanteSleep { get; private set; } = "La Voyante  se rendort…";/**Phrase pour que la voyante se rendort*/
        public string WereWolfCall { get; private set; } = "Les Loups-Garous se réveillent…";/**Phrase pour que les loups graous se reveille*/
        public string WereWolfChoice { get; private set; } = "Désignez un personnage à tuer…";/**Phrase pour que les loup garous decideent de tuer quelqu'un*/
        public string WereWolfSleep { get; private set; } = "Les loups garous se rendorment…";/**Phrase pour que les loup garous se rendorment*/
        public string SorciereCall { get; private set; } = "La Sorcière se réveille…";/**Phrase pour que la sorciere se reveille*/
        public string SorciereChoice { get; private set; } = "Voulez-vous utiliser votre potion de guérison ou votre potion d’empoisonnement ?";/**Phrase pour que la sorciere choicise quoi faire*/
        public string SorciereSleep { get; private set; } = "La Sorcière se rendort…";/**Phrase pour que la soriciere se rendort*/
    }
}
