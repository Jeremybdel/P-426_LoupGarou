﻿///ETML
///Auteur : Arthur Menétrey
///Date : 14.01.2020
///Description : Programme permetant de se loguer à une base de données et créer un compte
///Modifier par: Brunner Théo
///Raison: Ajout de la focntionnalité de récuperation des mots de passes
///
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Werewolf.Views
{
    static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login());
        }
    }
}
