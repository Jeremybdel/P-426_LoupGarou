var searchData=
[
  ['register_2ecs_59',['Register.cs',['../_register_8cs.html',1,'']]],
  ['register_2edesigner_2ecs_60',['Register.Designer.cs',['../_register_8_designer_8cs.html',1,'']]],
  ['resources_2edesigner_2ecs_61',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]]
];
