var searchData=
[
  ['sendcompletedcallback_75',['SendCompletedCallback',['../class_werewolf_1_1_send_mail.html#a8294d3046705f239c8a45301f0a5eac7',1,'Werewolf::SendMail']]],
  ['simpledataquerry_3c_20t_20_3e_76',['SimpleDataQuerry&lt; T &gt;',['../class_werewolf_1_1_model.html#a01a50ebe9cf9ddd3d67418b148ed4aac',1,'Werewolf::Model']]]
];
