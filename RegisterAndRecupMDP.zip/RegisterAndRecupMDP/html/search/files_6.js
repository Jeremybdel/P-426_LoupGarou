var searchData=
[
  ['sendmail_2ecs_62',['SendMail.cs',['../_send_mail_8cs.html',1,'']]],
  ['settings_2edesigner_2ecs_63',['Settings.Designer.cs',['../_settings_8_designer_8cs.html',1,'']]]
];
