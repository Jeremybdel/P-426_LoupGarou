var searchData=
[
  ['properties_48',['Properties',['../namespace_register_1_1_properties.html',1,'Register']]],
  ['register_49',['Register',['../namespace_register.html',1,'']]]
];
