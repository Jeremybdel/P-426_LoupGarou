var searchData=
[
  ['model_43',['Model',['../class_werewolf_1_1_model.html',1,'Werewolf']]]
];
