var searchData=
[
  ['regex_5fnickname_83',['REGEX_NICKNAME',['../class_werewolf_1_1_model.html#ab17b387181f8e2bb328b341acc7144ff',1,'Werewolf::Model']]]
];
